package com.capgemini.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.user.dto.Book;
import com.capgemini.user.dto.Category;
import com.capgemini.user.dto.Customer;
import com.capgemini.user.dto.Review;
import com.capgemini.user.dto.User;
import com.capgemini.user.exception.UserException;
import com.capgemini.user.service.UserService;

@CrossOrigin("http://localhost:4200")
@RestController
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private UserService custService;
	@Autowired
	private UserService catgService;
	@Autowired
	private UserService reviewService;
	@Autowired
	private UserService bookService;

	@GetMapping()

	public List<User> getAllUsers() throws UserException {
		return userService.getAllUsers();

	}

	@PostMapping("/addUsers")
	public List<User> addUsers(@RequestBody User user) throws UserException {
		return userService.addUsers(user);

	}

	@DeleteMapping("/users/{id}")
	public List<User> deleteUser(@PathVariable int id) throws UserException {
		return userService.deleteUser(id);

	}

	@PutMapping("/users/{id}")
	public List<User> updateUser(@PathVariable int id, @RequestBody User user) throws UserException {
		return userService.updateUser(id, user);

	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleErrors(Exception ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);

	}

	@GetMapping("/users/{id}")
	public User getById(@PathVariable int id) throws UserException {
		return userService.getById(id);

	}

	@GetMapping("/usersemail/{email}")
	public User getUserByEmail(@PathVariable String email) throws UserException {
		return userService.getUserByEmail(email);

	}

	@GetMapping("/customers")
	public List<Customer> showAllCustomers() throws UserException {
		return custService.showAllCustomers();
	}

	@PostMapping("/customers")
	public List<Customer> createCustomer(@RequestBody Customer customer) throws UserException {
		return custService.createCustomer(customer);

	}

	@DeleteMapping("/customers/{id}")
	public List<Customer> deleteCustomer(@PathVariable int id) throws UserException {
		return custService.deleteCustomer(id);
	}

	@GetMapping("/customers/{id}")
	public Customer getCustomerById(@PathVariable int id) throws UserException {
		return custService.getCustomerById(id);
	}

	@PutMapping("/customers/{id}")
	public List<Customer> editCustomer(@PathVariable int id, @RequestBody Customer customer) throws UserException {
		return custService.editCustomer(id, customer);

	}

	@GetMapping("/category")
	public List<Category> getAllCategories() throws UserException {
		return catgService.getAllCategories();
	}

	@PostMapping("/addcategory")
	public List<Category> addCategory(@RequestBody Category category) throws UserException {
		return catgService.addCategory(category);
	}

	@DeleteMapping("/category/{id}")
	public List<Category> deleteCategory(@PathVariable int id) throws UserException {
		return catgService.deleteCategory(id);
	}

	@PutMapping("/category/{id}")
	public List<Category> updateCategory(@PathVariable int id, @RequestBody Category category) throws UserException {
		return catgService.updateCategory(id, category);
	}

	@GetMapping("/getcat/{id}")
	public Category getByid(@PathVariable int id) throws UserException {
		return catgService.getByid(id);
	}

	@GetMapping("/reviews")
	public List<Review> getAllReviews() throws UserException {
		System.out.println(reviewService.getAllReviews());
		return reviewService.getAllReviews();
	}

	@PostMapping("/reviews")
	public List<Review> addReview(@RequestBody Review review) throws UserException {
		System.out.println(review);
		return reviewService.addReview(review);
	}

	@DeleteMapping("/reviews/{Id}")
	public List<Review> deleteReview(@PathVariable int Id) throws UserException {
		return reviewService.deleteReview(Id);

	}

	@PutMapping("/reviews/{Id}")
	public List<Review> editReview(@RequestBody Review review, @PathVariable int Id) throws UserException {
		return reviewService.editReview(Id, review);
	}

	@GetMapping("/reviews/{Id}")
	public Review getReviewById(@PathVariable int Id) throws UserException {
		return reviewService.getReviewById(Id);
	}

	@GetMapping("/books")
	public List<Book> getAllBook() throws UserException {
		return bookService.getAllBook();
	}

	@PostMapping("/books")
	public List<Book> createBook(@RequestBody Book book) throws UserException {
		return bookService.createBook(book);
	}

	@PutMapping("/books/{id}")
	public List<Book> editBook(@RequestBody Book book, @PathVariable int id) throws UserException {
		return bookService.editBook(id, book);
	}

	@DeleteMapping("/books/{id}")
	public List<Book> deleteBook(@PathVariable int id) throws UserException {
		return bookService.deleteBook(id);
	}

	@GetMapping("/books/{id}")
	public Book getBookById(@PathVariable int id) throws UserException {
		return bookService.getBookById(id);
	}

}
