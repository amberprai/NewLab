package com.capgemini.user.service;

import java.util.List;

import com.capgemini.user.dto.Book;
import com.capgemini.user.dto.Order;

public interface PLPService {

	List<Order> getAllOrders();

	Order getOrderbyId(int id);

	void delete(int id);

	void edit(int id, Order order);

	Order getOrder(int id);

	void addBook(String book, Order order);

	List<Book> getAllBooks();
}
