package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.beans.Book;
import com.example.demo.beans.Order;
import com.example.demo.beans.OrderedBook;
import com.example.demo.dao.BookRepo;
import com.example.demo.dao.OrderRepo;
import com.example.demo.dao.OrdererBookRepo;;

@Service
public class PLPServiceImpl implements PLPService {

	@Autowired
	private OrderRepo orderdao;

	@Autowired
	private OrdererBookRepo orderedBookDao;

	@Autowired
	private BookRepo bookDao;

//	private OrdererBookRepo  

	@Override
	public List<Order> getAllOrders() {
		System.out.println(orderdao.findAll());
		return orderdao.findAll();
	}

	@Override
	public Order getOrderbyId(int id) {

		return orderdao.findById(id).get();
	}

	@Override
	public void delete(int id) {
		orderdao.deleteById(id);
	}

	@Override
	public void edit(int id, Order order) {

		if (orderdao.findById(id) != null) {
			orderdao.save(order);
		}

	}

	@Override
	public Order getOrder(int id) {

		return orderdao.findById(id).get();
	}

	@Override
	public void addBook(String book, Order order) {
		/*
		 * OrderedBook orderedBook = new OrderedBook(); Book book1
		 * =bookDao.getBookbyname(book); Order newOrder=new Order();
		 * orderedBook.setBook(book1);
		 * 
		 * orderdao.save(order); orderedBookDao.save(orderedBook);
		 */
		}

	@Override
	public List<Book> getAllBooks() {
		return bookDao.findAll();
	}

}
