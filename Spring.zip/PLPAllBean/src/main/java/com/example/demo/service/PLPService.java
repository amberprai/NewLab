package com.example.demo.service;

import java.util.List;

import com.example.demo.beans.Book;
import com.example.demo.beans.Order;

public interface PLPService {

	List<Order> getAllOrders();
	Order getOrderbyId(int id);
	void delete(int id);
	void edit(int id, Order order);
	Order getOrder(int id);
	void addBook(String book, Order order);
	List<Book> getAllBooks();
}
