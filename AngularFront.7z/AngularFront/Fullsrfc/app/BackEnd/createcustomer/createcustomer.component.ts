import { Component, OnInit } from '@angular/core';


import { Router, ActivatedRoute } from '@angular/router';
import { Customer } from 'src/app/customer';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-createcustomer',
  templateUrl: './createcustomer.component.html',
  styleUrls: ['./createcustomer.component.css']
})
export class CreatecustomerComponent implements OnInit {
  customerData:Customer={id:0,email:'',fullname:'',password:'',confirmpassword:'',phonenumber:0,
  address:'',zipcode:0,city:'',country:''};
  constructor(private customerService:UserService,private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit() {
  }
  create(){
    console.log(this.customerData);
    this.customerService.createCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['login/adminhomepage/customerslist']);});
    
      
  }
  back(){
    this.router.navigate(['login/adminhomepage/customerslist']);
  }

}

