import { Component, OnInit } from '@angular/core';
import { Review } from 'src/app/review';
import { UserService } from 'src/app/service/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editreview',
  templateUrl: './editreview.component.html',
  styleUrls: ['./editreview.component.css']
})
export class EditreviewComponent implements OnInit {

  review:Review[];
  reviewData:Review={"index":0,"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''}
  constructor(private reviewService:UserService, 
    private router:Router,private route:ActivatedRoute){ }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{this.reviewService.getReview(params['id'])
    .subscribe((result)=>{this.reviewData=result;})}
    );
  }
  
  edit(){
    console.log(this.reviewData.id);
    this.reviewService.editReview(this.reviewData).subscribe(
      (data)=>{this.router.navigate(['login/adminhomepage/reviewlist']);}
    );}
    back(){
      this.router.navigate(['login/adminhomepage/reviewlist']);
    }
  
  
  }


