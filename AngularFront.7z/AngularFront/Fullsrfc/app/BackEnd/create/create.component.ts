import { Component, OnInit } from '@angular/core';
import { Userbean } from 'src/app/userbean';
import { UserService } from 'src/app/service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
userData:Userbean={"id":0,"email":'',"fullName":'',"password":''};
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
  }
  addUser(){
    
    this.userService.addUser(this.userData).subscribe(data=>{this.router.navigate(['users'])});

  }
  back(){
    this.router.navigate(['users']);
  }
}
