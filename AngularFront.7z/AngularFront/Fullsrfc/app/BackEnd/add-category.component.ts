import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Category } from '../category.interface';
import { UserService } from '../service/user.service';


@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {
  categoryData:Category={"id":0,"categoryName":''}
  constructor(private categoryService:UserService,private router:Router) { }

  ngOnInit() {
  }
  addCategory(){
   
    console.log(this.categoryData.categoryName);
      this.categoryService.addCategory(this.categoryData).subscribe((data)=>{this.router.navigate(['login/adminhomepage/category']);});
      
    }
    back(){
      this.router.navigate(['login/adminhomepage/category']);
    }
}
