import { Component, OnInit } from '@angular/core';


import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';
import { Customer } from 'src/app/customer';

@Component({
  selector: 'app-customermanagement',
  templateUrl: './customermanagement.component.html',
  styleUrls: ['./customermanagement.component.css']
})
export class CustomermanagementComponent implements OnInit {
  customers:Customer[];

    constructor(private customerService:UserService,private route:Router) { }
  
    ngOnInit() {
      this.customerService.getAllCustomers().subscribe
      ((data:Customer[])=>{this.customers=data;
      console.log("all"+this.customers)});
    }
      deleteCustomer(customer:Customer){
      alert: if(window.confirm("Are you sure you want to delete the customer with id "+customer.id))
      this.customerService.deleteCustomer(customer).subscribe
      ((data)=>{this.customers=this.customers.filter(c=>c!==customer)});
    }
    edit(id:number)
 {
this.route.navigate(['edit/:id']);
 }
 create( )
 {
this.route.navigate(['create']);
 }
  }
  
  