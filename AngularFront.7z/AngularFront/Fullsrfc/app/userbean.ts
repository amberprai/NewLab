export class Userbean {
    id:number;
    email:string;
   fullName:string;
    password:string;
  //static fullName: string;

}
