export interface Category{
    
    id:number;
    categoryName:String;
}