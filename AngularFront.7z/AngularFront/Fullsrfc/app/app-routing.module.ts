import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './BackEnd/show/show.component';

import { CreateComponent } from './BackEnd/create/create.component';
import { EditComponent } from './BackEnd/edit/edit.component';
import { HomepageComponent } from './BackEnd/homepage/homepage.component';
import { LoginpageComponent } from './BackEnd/loginpage/loginpage.component';
import { AdminhomepageComponent } from './BackEnd/adminhomepage/adminhomepage.component';
import { CustomermanagementComponent } from './BackEnd/customermanagement/customermanagement.component';
import { CreatecustomerComponent } from './BackEnd/createcustomer/createcustomer.component';
import { EditcustomerComponent } from './BackEnd/editcustomer/editcustomer.component';
import { CategorylistComponent } from './BackEnd/categorylist.component';
import { AddCategoryComponent } from './BackEnd/add-category.component';
import { EditCategoryComponent } from './BackEnd/edit-category.component';
import { ReviewlistingpageComponent } from './BackEnd/reviewlistingpage/reviewlistingpage.component';
import { EditreviewComponent } from './BackEnd/editreview/editreview.component';
import { BookListComponent } from './BackEnd/Booklist/booklist.component';
import { CreatebookComponent } from './BackEnd/createbook/createbook.component';
import { EditbookComponent } from './BackEnd/editbook/editbook.component';


const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:'login',component:LoginpageComponent},
  {path:'login/adminhomepage',component:AdminhomepageComponent},
  {path:'users',component:ShowComponent},
  {path:'createuser',component:CreateComponent},
  {path:'login/adminhomepage/users/edituser/:id',component:EditComponent},
  {path:'newuser',component:CreateComponent},
  {path:'login/adminhomepage/customerslist',component:CustomermanagementComponent},
  {path:'customerslist/create',component:CreatecustomerComponent},
  {path:'customerslist',component:CustomermanagementComponent},
  {path:'customerslist/create',component:CreatecustomerComponent},
  {path:'customerslist/edit/:id',component:EditcustomerComponent},
  {path:'login/adminhomepage/users/customerslist/edit/:id',component:EditcustomerComponent},
  {path:'category',component:CategorylistComponent},
  {path:'category/add',component:AddCategoryComponent},
  {path:'category/edit/:id',component:EditCategoryComponent},
  {path:'users/category/edit/:id',component:EditCategoryComponent},
  {path:'category/users',component:ShowComponent},
  {path:'login/adminhomepage/category/users/category/add',component:AddCategoryComponent},
  {path:'newcustomer',component:CreatecustomerComponent},
  {path:'newcategory',component:AddCategoryComponent},
  {path:'reviewlist',component:ReviewlistingpageComponent},
  {path:'reviewlist/editreview/:id',component:EditreviewComponent},
  {path:'booklist',component:BookListComponent},
  {path:'booklist/create',component:CreatebookComponent},
  {path:'booklist/edit/:id',component:EditbookComponent},
  {path:'newbook',component:CreatebookComponent},

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
