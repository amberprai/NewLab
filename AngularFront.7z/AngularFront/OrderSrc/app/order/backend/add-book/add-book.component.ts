import { Component, OnInit } from '@angular/core';
import { AdminService } from '../service/admin.service';
import { Book, Order, OrderedBook } from '../class/order';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {
allBooks:Book;
quantity:number;
selectedBook:string;

orders:Order;
ordered:OrderedBook;

  constructor(private adminService:AdminService,private router: Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.adminService.getAllBooks().subscribe(data =>{console.log(data);this.allBooks=data})
  console.log(this.allBooks.title);
  this.route.params.subscribe((params) => {
    this.adminService.getOrderById(params['id'])
      .subscribe((result) => {
        console.log(result); this.orders = result;
      })
  })
  }
  addBook(newBook:Book)
  { 
    this.allBooks=newBook;
    return this.allBooks.title;
    this.adminService.addBooks(this.allBooks,this.orders).subscribe(data=>{this.router.navigate['editOrder']});
    window.alert("Book "+this.allBooks +"Added to order Id :");
  }
  


  

}
