import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Order, Book, OrderedBook } from '../class/order';
import { OrderDetail } from 'src/app/order-detail';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
  
  orders: Order[];
  orderDetails: OrderDetail[];
  Bookid=0;
 allBooks:Book[];

  url1: string = "http://localhost:4000";
  constructor(private http: HttpClient) {
    this.getOrder().subscribe(data => this.orders = data);
  }
  getOrder(): Observable<Order[]> {
    return this.http.get<Order[]>(this.url1);
  }
  public getData() {
    return this.orders;
  }
  public setOrder(orders: Order[]) {
    this.orders = orders;
  }
  public getOrderList() {
    return this.http.get<Order[]>(this.url1+"/adminOrderList");
  }
  
  public deleteOrder(list: Order) {
    console.log(list);
    return this.http.delete<Order[]>(this.url1 + "/delete/" + list.id);
  }

  public getOrderById(id:number){
    console.log(id);
    this.Bookid=id;
    return this.http.get<Order>(this.url1+"/getorder/"+id);
   
  }

  public editOrder(order:Order)
  {
    console.log(order);
    return this.http.put(this.url1+"/edit/"+order.id,order);
  }
  public getBooks() {
   return this.http.get<Book>(this.url1+"/order/"+ this.Bookid);
  }
  public getOrderedBooks() {
   return this.http.get<OrderedBook>(this.url1+"/order/"+this.Bookid)
  }
  public getAllBooks() {
    return this.http.get<Book>(this.url1+"/adminAddBooks");
  }
  public addBooks(allBooks:Book, orders:Order) {
    console.log("asdasd "+allBooks)
    console.log("sadasd "+ orders)
    return this.http.post(this.url1+"/addBook/",orders)
  }
}