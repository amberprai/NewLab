import { Orderhistory } from './orderhistory';

describe('Orderhistory', () => {
  it('should create an instance', () => {
    expect(new Orderhistory()).toBeTruthy();
  });
});
