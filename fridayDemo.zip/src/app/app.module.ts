import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentslistComponent } from './students/studentslist.component';
import { AddstudentComponent } from './students/addstudent.component';
import { StartPageComponent } from './students/start-page.component';
import{FormsModule} from '@angular/forms';
import { UpdateStudentComponent } from './students/update-student.component';
import { SearchStudentComponent } from './students/search-student.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentslistComponent,
    AddstudentComponent,
    StartPageComponent,
    UpdateStudentComponent,
    SearchStudentComponent
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
