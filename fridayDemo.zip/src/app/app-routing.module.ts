import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentslistComponent } from './students/studentslist.component';
import { AddstudentComponent } from './students/addstudent.component';
import { StartPageComponent } from './students/start-page.component';
import { SearchStudentComponent } from './students/search-student.component';
import { UpdateStudentComponent } from './students/update-student.component';



const routes: Routes = [
{path:"students",component:StudentslistComponent},
{path:"add",component:AddstudentComponent},
{path:'',component:StudentslistComponent},
{path:'search',component:SearchStudentComponent},
{path:'students/update/:id',component:UpdateStudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
