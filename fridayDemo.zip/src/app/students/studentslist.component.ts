import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-studentslist',
  templateUrl: './studentslist.component.html',
  styleUrls: ['./studentslist.component.css']
})
export class StudentslistComponent implements OnInit {

  students:IStudent[];
  student:IStudent;
  sortByName:IStudent[];
  constructor(private studentService:StudentService) { }

  ngOnInit() {
    if(!this.studentService.getData()){ //Asynchrounous programming
    this.studentService.getStudents().subscribe(data=>{
      this.students=data;
      this.studentService.setStudents(this.students);
    });
    }
    else{
      this.students=this.studentService.getData();
    }
  }
  deleteStudent(id:number)
  {
    this.studentService.deleteStudent(id);
    this.students=this.studentService.getData();
  }

  filterByName(studentArray:IStudent[]) {
    console.log(this.sortByName);
    return this.students.sort((a, b) => a['name'] > b['name'] ? 1 : a['name'] === b['name'] ? 0 : -1);
  }

  updateStudent(student:IStudent){
    this.student=student;
  }

}
