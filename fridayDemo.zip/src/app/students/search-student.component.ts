import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
  students:IStudent[];

  constructor(private studentService:StudentService) { }

  ngOnInit() {
  }
  searchStudent(data){
    this.students=this.studentService.getData().filter(s=>s.name==data.name);
    console.log(this.students);
  }

}
