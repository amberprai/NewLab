import { Component, OnInit } from '@angular/core';
import { IStudent } from './student.interface';
import { StudentService } from './student.service';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { StudentslistComponent } from './studentslist.component';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit {
  studentData:IStudent={"id":0,"name":'',"age":0,"gender":'',"mobile":"0"};
  constructor(private studentService:StudentService,private router:Router,private studentList:StudentslistComponent) {
    this.studentData=this.studentList.student;
    console.log(this.studentData);
   }

  ngOnInit() {
    
  }

  update(){
    console.log(this.studentData.name);
   this.studentService.deleteStudent(this.studentData.id);
   this.studentService.addStudent(this.studentData);
  }

}
