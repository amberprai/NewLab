export class Student {
    id:number;
    name:string;
    gender:string;
    age:number;
    mobile:string;
    address:string;
    
}
