import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-search',
  templateUrl: './show-search.component.html',
  styleUrls: ['./show-search.component.css']
})
export class ShowSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
