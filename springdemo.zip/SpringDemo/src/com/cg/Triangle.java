package com.cg;

import java.util.List;

public class Triangle {
	/*
	 * private String type; private int height;
	 * 
	 * 
	 * 
	 * public int getHeight() { return height; }
	 * 
	 * public void setHeight(int height) { this.height = height; }
	 * 
	 * public String getType() { return type; }
	 * 
	 * public void setType(String type) { this.type = type; }
	 * 
	 * 
	 * public void draw() {
	 * System.out.println(type+"   Inside Triangle of height "+height); }
	 * 
	 * public Triangle() { super(); // TODO Auto-generated constructor stub }
	 * 
	 * public Triangle(String type, int height) { super(); this.type = type;
	 * this.height = height; }
	 */

	private Point pointA;
	private Point pointB;
	private Point pointC;

	public Point getPointA() {
		return pointA;
	}

	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}

	public Point getPointB() {
		return pointB;
	}

	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}

	public Point getPointC() {
		return pointC;
	}

	public void setPointC(Point pointC) {
		this.pointC = pointC;
	}

	public Triangle(Point pointA, Point pointB, Point pointC) {
		super();
		this.pointA = pointA;
		this.pointB = pointB;
		this.pointC = pointC;
	}

	public Triangle() {
		super();
	}

	public void draw() {
		System.out.println("Point A (" + pointA.getX() + "," + pointA.getY() + ")");
		System.out.println("Point B (" + pointB.getX() + "," + pointB.getY() + ")");
		System.out.println("Point C (" + pointC.getX() + "," + pointC.getY() + ")");
	}

	/*
	 * private List<Point> points;
	 * 
	 * public List<Point> getPoints() { return points; }
	 * 
	 * 
	 * 
	 * public void setPoints(List<Point> points) { this.points = points; }
	 * 
	 * public void draw() { for (Point point : points) {
	 * System.out.println("Point ("+point.getX()+","+point.getY()+")"); } }
	 */

}
